devices = [
   #{
   #   "address": "devnetsandboxiosxec8k.cisco.com",
   #   "port": 830,
   #   "username": "marco.polverini",
   #   "password": "Fz65KotDuV-1-",
   #   "ospf_processId":1,
   #   "ospf_ip":"10.1.1.0",
   #   "ospf_wildcard":"0.255.255.255",
   #   "ospf_area":"0.0.0.0"
   #},

   {
      "device_id":1,
      "address": "devnetsandboxiosxec8k.cisco.com",
      "port": 830,
      "username": "matteo.ventali",
      "password": "",
   }
]