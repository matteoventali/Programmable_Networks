devices = [
   {
      "address": "devnetsandboxiosxec8k.cisco.com",
      "port": 830,
      "username": "",
      "password": "",
      "ospf_processId":1,
      "ospf_ip":"10.1.1.0",
      "ospf_wildcard":"0.255.255.255",
      "ospf_area":"0.0.0.0"
   },
]